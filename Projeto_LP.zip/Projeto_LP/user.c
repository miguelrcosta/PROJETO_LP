#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "user.h"
#include "management.h"

